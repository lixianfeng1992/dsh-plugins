# dsh-skill-hub

Synchronizes the root `skills/` directory of one GitHub or GitLab repository into the active DSH profile with symbolic links.

The plugin accepts `{ repositoryUrl, dshHome?, profile? }` as its config. `dshHome` defaults to `DSH_HOME`, and `profile` defaults to `DSH_PROFILE` or `web`. It exposes a `skillHub` service with `sync()` and `getState()` methods. Credentials are delegated to Git and are never persisted.
