import { Context } from "@deepseek-ai/cordis";
//#region src/types.d.ts
interface SkillHubConfig {
  repositoryUrl: string;
  dshHome?: string;
  profile?: string;
}
interface SyncCounts {
  linked: number;
  skipped: number;
  failed: number;
}
interface SyncResult extends SyncCounts {
  repositoryUrl: string;
  checkoutPath: string;
  syncedAt: string;
  errors: string[];
}
interface SkillHubState {
  repositoryUrl: string;
  checkoutPath: string;
  profile: string;
  lastSync?: SyncResult;
  createdLinks: string[];
}
//#endregion
//#region src/plugin.d.ts
declare const name = "dsh-skill-hub";
declare const provide = "skillHub";
declare function apply(ctx: Context, config?: SkillHubConfig): void;
//#endregion
//#region src/sync.d.ts
declare class SkillHubSynchronizer {
  private readonly config;
  private readonly dshHome;
  private readonly profile;
  private readonly statePath;
  private state?;
  private running?;
  constructor(config: SkillHubConfig);
  getState(): Promise<SkillHubState>;
  sync(): Promise<SyncResult>;
  private performSync;
}
//#endregion
//#region src/repository.d.ts
interface RepositoryRef {
  url: string;
  name: string;
}
declare function parseRepositoryUrl(input: string): RepositoryRef;
declare function repositoryPaths(dshHome: string, profile: string, ref: RepositoryRef): {
  base: string;
  checkout: string;
  skills: string;
  links: string;
  state: string;
};
//#endregion
export { type RepositoryRef, type SkillHubConfig, type SkillHubState, SkillHubSynchronizer, type SyncCounts, type SyncResult, apply, name, parseRepositoryUrl, provide, repositoryPaths };