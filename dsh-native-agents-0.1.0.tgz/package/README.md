# dsh-native-agents

Continuable Codex and Claude Code agents for DeepSeek Harness. DSH owns child identity, FIFO delivery, `send_message`, interruption, and its visible transcript. The plugin keeps Codex threads and Claude Code sessions in their native formats under `~/.dsh/native-agents` by default.

The bundle adds two continuable tools:

- `codex_agent`
- `claude_code_agent`

Both children have no DSH tools. Their native products execute tools and preserve native history. Follow-up messages use DSH's existing `send_message` tool.

## Local installation

Build and pack from the `dsh-plugins` workspace:

```sh
pnpm --filter dsh-native-agents build
pnpm --filter dsh-native-agents pack
```

Install the generated archive from the DeepSeek Harness workspace, matching the other local plugins:

```sh
pnpm dsh plugin add --profile web /Users/allenli/workspace/dsh-plugins/packages/dsh-native-agents/dist/dsh-native-agents-0.1.0.tgz
pnpm dsh web --no-open
```

## Configuration

The default configuration enables both providers in unattended safe modes:

```yaml
- id: native-agents
  name: dsh-native-agents
  config:
    storageRoot: /absolute/path/to/native-agent-state
    codex:
      permissionMode: never
    claudeCode:
      permissionMode: dontAsk
```

`storageRoot` defaults to `<DSH_HOME>/native-agents`. Its `providers/codex` directory is used as `CODEX_HOME`; `providers/claude-code` is used as `CLAUDE_CONFIG_DIR`. Authenticate the native products against those homes or supply credentials explicitly through each provider's `env` configuration.

Automatic DSH LLM retry is disabled for both routes. Missing, corrupt, or incomplete bindings fail without creating a replacement conversation.
