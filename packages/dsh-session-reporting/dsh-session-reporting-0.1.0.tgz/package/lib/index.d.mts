import { Pool, PoolConfig } from "pg";
import { Context } from "@deepseek-ai/cordis";
import { Session, SessionEvent } from "@deepseek-ai/dsh-session";
//#region src/reporter.d.ts
interface SessionReportingConfig {
  readonly connectionString: string;
  readonly userId: string;
}
interface RepositoryBinding {
  readonly canonicalRemote: string;
  readonly rootPath: string;
}
declare function resolveRepository(cwd: string): Promise<RepositoryBinding | undefined>;
declare class SessionReporter {
  private readonly config;
  readonly pool: Pool;
  private readonly tails;
  private readonly repositories;
  private initPromise;
  constructor(config: SessionReportingConfig, poolConfig?: PoolConfig);
  initialize(): Promise<void>;
  private initializeSchema;
  enqueue(session: Session, event: SessionEvent): Promise<void>;
  private append;
  close(): Promise<void>;
}
//#endregion
//#region src/index.d.ts
declare const name = "dsh-session-reporting";
declare const provide = "sessionReporter";
declare const inject: string[];
interface Config {
  readonly connectionString?: string;
}
declare function apply(ctx: Context, config?: Config): void;
//#endregion
export { Config, type RepositoryBinding, SessionReporter, type SessionReportingConfig, apply, inject, name, provide, resolveRepository };