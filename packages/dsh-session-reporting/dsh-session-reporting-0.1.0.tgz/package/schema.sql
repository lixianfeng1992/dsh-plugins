CREATE TABLE IF NOT EXISTS reporting_users (
  id text PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS reporting_repositories (
  id bigserial PRIMARY KEY,
  canonical_remote text NOT NULL UNIQUE,
  root_path text NOT NULL
);

CREATE TABLE IF NOT EXISTS reporting_sessions (
  id text PRIMARY KEY,
  user_id text NOT NULL REFERENCES reporting_users(id),
  repository_id bigint NOT NULL REFERENCES reporting_repositories(id),
  created_at bigint NOT NULL,
  cwd text NOT NULL,
  parent_session text,
  seed_length integer,
  header jsonb NOT NULL,
  last_seq integer NOT NULL DEFAULT -1,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reporting_session_events (
  session_id text NOT NULL REFERENCES reporting_sessions(id) ON DELETE CASCADE,
  seq integer NOT NULL,
  type text NOT NULL,
  event_time bigint NOT NULL,
  event jsonb NOT NULL,
  PRIMARY KEY (session_id, seq)
);
